# Assignment Git Commit Diff Web Application

This project(Assignment) is a full-stack web application that allows users to view details of a Git commit and its code differences in a GitHub repository.

## Prerequisites

Before you begin, ensure you have the following tools and dependencies installed:

- Node.js (https://nodejs.org/)
- npm (Node Package Manager) - usually included with Node.js installation
- Git (https://git-scm.com/) - for version control (optional)

## Setup

### Frontend

1. Navigate to the `frontend-code` directory:  run: cd frontend-code
2. Install the necessary dependencies:         run: npm install(node16.0.0)
3. Start the frontend development server:      run: npm start

The frontend should be accessible at `http://localhost:3000`. You will see the home page with a link to a sample commit for testing.

### Backend
1. Navigate to the `backend-code` directory: run: cd backend-code
2. Install the necessary dependencies:       npm install
3. Start the backend server:                 node index.js

The backend server should be running on `http://localhost:3001`. It will serves data to the frontend.

## Usage

1. Open your web browser and access the frontend at `http://localhost:3000`.
2. You'll see the home page with a link to a commit for testing.
3. From there you can also go to another link by passing owner, repo, commitSHA





